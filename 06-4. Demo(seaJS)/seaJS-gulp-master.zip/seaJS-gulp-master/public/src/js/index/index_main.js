seajs.use("/public/src/js/index/index.js");
