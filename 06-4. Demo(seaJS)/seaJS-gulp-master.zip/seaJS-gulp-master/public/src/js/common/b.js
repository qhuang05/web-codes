define(function(require,exports,module){
    console.log('bbbbbbbbbbb');
}); 
