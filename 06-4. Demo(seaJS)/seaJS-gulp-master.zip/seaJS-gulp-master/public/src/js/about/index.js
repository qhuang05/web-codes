define(function(require,exports,module){
    require('../common/c');
    require('../common/b');
    console.log('index');
    console.log('about')
}); 
